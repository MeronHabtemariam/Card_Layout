package main;

import view.ContactListView;
import view.ContactDetailsView;
import view.ContactFormView;
import model.Contact;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class ContactManager {
    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private ContactListView contactListView;
    private ContactDetailsView contactDetailsView;
    private ContactFormView contactFormView;
    private ArrayList<Contact> contacts;

    public ContactManager() {
        frame = new JFrame("Contact Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        contacts = new ArrayList<>();

        contactListView = new ContactListView(this);
        contactDetailsView = new ContactDetailsView(this);
        contactFormView = new ContactFormView(this);

        mainPanel.add(contactListView.getPanel(), "ContactList");
        mainPanel.add(contactDetailsView.getPanel(), "ContactDetails");
        mainPanel.add(contactFormView.getPanel(), "ContactForm");

        frame.add(mainPanel);
        frame.setVisible(true);
    }

    public void showCard(String cardName) {
        cardLayout.show(mainPanel, cardName);
    }

    public ArrayList<Contact> getContacts() {
        return contacts;
    }

    public ContactListView getContactListView() {
        return contactListView;
    }

    public ContactDetailsView getContactDetailsView() {
        return contactDetailsView;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ContactManager::new);
    }
}
