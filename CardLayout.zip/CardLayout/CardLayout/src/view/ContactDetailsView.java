package view;

import main.ContactManager;

import javax.swing.*;
import java.awt.*;

public class ContactDetailsView {
    private JPanel panel;
    private JLabel detailsLabel;
    private ContactManager manager;

    public ContactDetailsView(ContactManager manager) {
        this.manager = manager;
        panel = new JPanel(new BorderLayout());
        detailsLabel = new JLabel("Select a contact to view details.");
        JButton backButton = new JButton("Back to List");

        backButton.addActionListener(e -> manager.showCard("ContactList"));

        panel.add(detailsLabel, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);
    }

    public JPanel getPanel() {
        return panel;
    }

    public void setDetails(String details) {
        detailsLabel.setText("<html>" + details.replaceAll("\n", "<br>") + "</html>");
    }
}
