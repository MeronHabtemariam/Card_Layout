package view;

import main.ContactManager;
import model.Contact;

import javax.swing.*;
import java.awt.*;

public class ContactListView {
    private JPanel panel;
    private JList<String> contactList;
    private DefaultListModel<String> contactListModel;
    private ContactManager manager;

    public ContactListView(ContactManager manager) {
        this.manager = manager;
        panel = new JPanel(new BorderLayout());
        contactListModel = new DefaultListModel<>();
        contactList = new JList<>(contactListModel);
        JButton addButton = new JButton("Add New Contact");
        JButton viewButton = new JButton("View Details");
        JButton deleteButton = new JButton("Delete Contact");

        addButton.addActionListener(e -> manager.showCard("ContactForm"));
        viewButton.addActionListener(e -> {
            int index = contactList.getSelectedIndex();
            if (index != -1) {
                Contact contact = manager.getContacts().get(index);
                manager.getContactDetailsView().setDetails(contact.getName() + "\n" + contact.getPhone() + "\n" + contact.getEmail());
                manager.showCard("ContactDetails");
            } else {
                JOptionPane.showMessageDialog(null, "Please select a contact to view details.");
            }
        });

        deleteButton.addActionListener(e -> {
            int index = contactList.getSelectedIndex();
            if (index != -1) {
                manager.getContacts().remove(index);
                contactListModel.remove(index);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a contact to delete.");
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(deleteButton);

        panel.add(new JScrollPane(contactList), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
    }

    public JPanel getPanel() {
        return panel;
    }

    public void addContact(String name) {
        contactListModel.addElement(name);
    }
}
