package view;

import main.ContactManager;
import model.Contact;

import javax.swing.*;
import java.awt.*;

public class ContactFormView {
    private JPanel panel;
    private JTextField nameField, phoneField, emailField;
    private ContactManager manager;

    public ContactFormView(ContactManager manager) {
        this.manager = manager;
        panel = new JPanel(new GridLayout(4, 2));
        nameField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();
        JButton saveButton = new JButton("Save Contact");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(e -> saveContact());
        cancelButton.addActionListener(e -> manager.showCard("ContactList"));

        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Phone:"));
        panel.add(phoneField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(saveButton);
        panel.add(cancelButton);
    }

    public JPanel getPanel() {
        return panel;
    }

    private void saveContact() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields must be filled out.");
            return;
        }

        manager.getContacts().add(new Contact(name, phone, email));
        manager.getContactListView().addContact(name);
        nameField.setText("");
        phoneField.setText("");
        emailField.setText("");

        manager.showCard("ContactList");
    }
}
